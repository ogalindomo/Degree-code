Code by Oscar Galindo
ID 80585887

For the parameters please input

circles and rectangles followed by the number of each that you will like to generate.

