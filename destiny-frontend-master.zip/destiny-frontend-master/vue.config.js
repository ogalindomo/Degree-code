module.exports = {
    devServer:{
	public: '0.0.0.0'
    }
}
