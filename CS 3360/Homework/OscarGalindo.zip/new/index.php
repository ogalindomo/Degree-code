<?php 
require_once '../play/GameBoard.php';
define('STRATEGY', 'strategy'); // constant
$strategies = array("Smart", "Random"); // supported strategies

if (!array_key_exists(STRATEGY, $_GET)) 
{ 
    communicate(false,null);//Strategy not specified.
    exit; 
}
else if(array_key_exists(STRATEGY, $_GET))//Strategy is specficied.
{   
    $strategy = $_GET[STRATEGY];//Reads the strategy choice provided by the client.
    if ($strategy == "null")//If the strategy reads null then the error is called.
        communicate(false, null);
    else if(in_array($strategy, $strategies))//If strategy exists then the execution begins.
        communicate($strategy, true);
    else
        communicate($strategy,false);//If strategy is not present as a possibility for the server an error is displayed.
}

 function communicate ($firstPart, $existence)
 {   
     global $strategy;
     if($existence == true)
     {
         define(id,uniqid("ogm"));//My intials are added to the front of the unique id.
         echo json_encode(array('response' => $existence, 'pid' => id));//The execution responds the client with a unique id and a true.
         $directory =  "../writable/"; //Server
         $filename = $directory.id.".txt";
         //$filename = "/Users/oscargalindo/eclipse-workspace/ConnectFour/src/new/".id.".txt";
         $file = fopen($filename, "w");//Opens the file to store the new game's board and strategy choice.
         $board = new Board();
         $entries = $board->getBoard();
         $diskNum = $board->getDiskNum();
         $gametype = json_encode(array('strategy'=>$strategy, 'board' => $entries, 'disk' =>$diskNum));//The state of a new board is encoded.
         fwrite($file, $gametype);//Writes the file
         fclose($file);//Closes the opened file.
     }
     else if($existence == false)//If strategy is strange to the system this error appears.
     {
         echo json_encode(array('response' => false, 'reason' => 'Unknown Strategy'));
     }
     else //If strategy is not determined this error appears.
     {
         echo json_encode(array('response' => false,'reason' => 'Strategy not specified'));
     }
 }
 
?>