<?php
/**
 * @author oscargalindo
 */
require_once '../play/GameBoard.php';
include ("../play/Move.php");

define('gameid', 'pid');
define('played_column', 'move');
define('disknum','disk');

$id = $_GET[gameid];
$played_column = $_GET[played_column];

//echo ($id." Space Moved:".$played_column); Testing
$int_column = intval($played_column);
//$filename = "/Users/oscargalindo/eclipse-workspace/ConnectFour/src/new/".$id.".txt";
$directory =  "../writable/";
$filename = $directory.$id.".txt";

if(file_exists($filename) && (0 <= $int_column && $int_column < 7)&& $played_column != "")//If game exists and valid move.
{
    communicate("Valid");
}
else if($id == "")//Error given in case the execution did not provide a unique id.
{
    communicate("Non-existent");
    exit;
    
}
else if($played_column == "")//Error given in case no played column number was given.
{
    communicate("Null-Move");
    exit;
}
else if(!(0 <= $int_column && $int_column < 7) && $played_column != "")//Error in case a movement was attempted at a location outside the board's limits.
{
    communicate("Invalid");
    exit;
}
else//If all parameters are provided but the pid is not existen then this error is state is provided.
{
    communicate("Unknown");
    exit;
}

function communicate ($situation)
{
    global $int_column;
    global $filename;
    global $id;
    switch ($situation)
    {
        case "Valid":
            /////////////Extract State///////////////////
            $open_file = fopen($filename, "r");
            $read = fgets($open_file);
            $contains = json_decode($read);
            $read_strategy = $contains -> strategy;
            $board_representation = $contains -> board;
            $num_disks = $contains -> disk;
            /////////////Reconstruct State///////////////
            $reconstructed_board = new Board();
            $reconstructed_board->setBoard($board_representation,$num_disks);
            /////////////Create Response/////////////////
            $player_move = new Move($reconstructed_board,null,$int_column,'p');
            $opponent_move = new Move($reconstructed_board,$read_strategy,null,'a');
            $file = fopen($filename, "w");
            $gametype = json_encode(array('strategy'=>$read_strategy, 'board' => $reconstructed_board->getBoard(), 'disk' =>$reconstructed_board->getDiskNum()));
            fwrite($file, $gametype);
            fclose($file);
            if ($player_move->isWin == 'true' || $player_move->isDraw =='true') {//Check if the player won or draw.
                echo createResponse($player_move); 
                exit;//The opponent's move is not trasmitted if player won.
            }
            echo (createResponse($player_move, $opponent_move));//In case player did not win the server makes a move.
            break;
            //echo $reconstructed_board->getCoordinate(0, 0);//Test Entry of the recosntructed board.
            
        case "Non-existent":
            
            $response = json_encode(array("response" => false, "reason" => "Pid not specified"));//Id not given.       
            echo $response;
            break;
            
        case "Invalid":
            $response = json_encode(array("response"=> false, "reason" =>"Invalid Slot,".$int_column));//Invalid slot played.
            echo $response;
            break;
            
        case "Null-Move":
            $response = json_encode(array("response"=> false, "reason" =>"Move not specified"));//Move parameter is not provided.
            echo $response;
            break;
            
        case "Unknown":
            $response = json_encode(array("response"=> false, "reason" =>"Unknown pid"));//All parameters are given but the pid does not exist.
            echo $response;
            break;
    }
    
    
}

function createResponse($playerMove, $opponentMove = null)//This parameter constructs the answer
{
    $result = array("response" => true, "ack_move" => $playerMove);
    if ($opponentMove != null) {$result["move"] = $opponentMove; }
    return json_encode($result);
}

?>