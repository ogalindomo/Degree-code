<?php
/**
 * @author oscargalindo
 */
require_once '../play/GameBoard.php';
require_once '../play/MoveStrategy.php';
class SmartStrategy extends MoveStrategy
{
    private $structure;
    public function __construct(Board &$board)
    {
        $this->structure = $board->getBoard();
    }
    
    public function get_new_move()
    {
       $column = 0;
       $max_connections = 0;
       for($y = 0; $y < 6; $y += 1) 
       {
          $possible_connections = $this->checkColumn($y);
          if($possible_connections >= $max_connections)
          {
              $column = $y;
              $max_connections = $possible_connections;
          }
       }
       return $column;
    }   
       
    private function checkColumn($y)
    {
        $x = $this->findMinimum($y);
        $max = 0;
        if($x>=0)
        {
            if($this->checkPlaces($x,$y,1,0) > $max)//Checks up direction
            {
                $max = $this->checkPlaces($x,$y,1,0);exit;
            }
            else if($this->checkPlaces($x,$y,-1,0) > $max)//Checks down direction
            {
                $max = $this->checkPlaces($x,$y,-1,0);exit;
            }
            else if($this->checkPlaces($x,$y,0,1) > $max)//Checks to the right direction
            {
                $max = $this->checkPlaces($x,$y,0,1);exit;
            }
            else if($this->checkPlaces($x,$y,0,-1) > $max)//Checks to the left direction.
            {
                $max = $this->checkPlaces($x,$y,0,-1);exit;
            }
            else if($this->checkPlaces($x,$y,1,-1) > $max)//Checks up-left direction.
            {
                $max = $this->checkPlaces($x,$y,1,-1);exit;
            }
            else if($this->checkPlaces($x,$y,1,1) > $max)//Checks up-right direction.
            {
                $max = $this->checkPlaces($x,$y,1,1);exit;
            }
            else if($this->checkPlaces($x,$y,-1,1) > $max)//Checks down-right direction.
            {
                $max = $this->checkPlaces($x,$y,-1,1);exit;
            }
            else if($this->checkPlaces($x,$y,-1,-1) > $max)//Checks down left direction.
            {
                $max = $this->checkPlaces($x,$y,-1,-1);exit;
            }
        }
        if($x = -1)
            return -1;
        else 
            return $max;
                
    }
    public function checkPlaces($x, $y, $dx, $dy) {
        $x += $dx;
        $y += $dy;
        $count = 0;
        for($i = 0; $i < 4 && $this->structure[$x][$y] == 'p' && $x >= 0 && $x < 6 && $y >= 0 && $y < 7; $x += $dx, $y += $dy, $i += 1)//Counts the consecutive
        //entries in the specify direction for a given entity
        {
            if($this->entries[$x][$y] == 'p')
                $count += 1;
        }
        return $count;
    }
    public function findMinimum($y)
    {
        $minimum_index = 0;
        for($x = 0; $x < 6; $x+=1)
            if($this->structure[$x][$y] == 'u')
                $minimum_index = $x;
        if($this->structure[0][$y] != 'u')
            return -1;
        return $minimum_index;
    }
}
?>