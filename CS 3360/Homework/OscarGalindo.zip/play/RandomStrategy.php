<?php
/**
 * @author oscargalindo
 */
require_once '../play/GameBoard.php';
require_once '../play/MoveStrategy.php';
class RandomStrategy extends MoveStrategy
{
    private $structure;
    public function __construct(Board &$board) 
    {
        $this->structure = $board->getBoard();//Retrieves the array that represents the board.

    }
    public function get_new_move()
    {
        
        $random_column = rand(0,50);
        $random_column = $random_column%7;
        if($this->structure[0][$random_column] == 'u')//If the uppermost entry in that column is 
                                                      //unsued (u) then it returns the value for that column
        {
            return $random_column;
        } 
        else //If the column selected is entirely used then a new column is choosen recursively.
        {
            
            return $this->get_new_move();
        }
    }
    
}
?>