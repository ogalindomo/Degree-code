<?php 
require_once '../play/GameBoard.php';
Abstract class MoveStrategy//Abstract Class that forces other classes to implement get_new_move
{
    abstract public  function __construct(Board &$reference);
    abstract public  function get_new_move();    
}
?>