<?php 
/**
 * @author oscargalindo
 */
class Board
{
    private $entries;//Stores the array that represents the board.
    private $diskCount;//How many disks are placed are stored here.
    public $win_coord;//Coordinates of victory are stored here.
    public function __construct()
    {
        $this -> entries = array(
            array('u','u','u','u','u','u','u'),
            array('u','u','u','u','u','u','u'),
            array('u','u','u','u','u','u','u'),
            array('u','u','u','u','u','u','u'),
            array('u','u','u','u','u','u','u'),
            array('u','u','u','u','u','u','u'));//This constructs the array that represents the board.
        $this -> diskCount = 0;//Initiates the count of disks to 0.
    }
    
    public function placeDisk($slot,$entity)//Places, or changes, the entry where a new disk was located.
    {
        
        $prov_row = 0;
        for($x = 0; $x < count($this->entries) && $this->entries[$x][$slot] == 'u'; $x+=1)
        {
            $prov_row = $x;
        }
        $this->setCoordinate($prov_row, $slot, $entity);//Indicates which entity has placed a disk at a specific coordinate.
        $this->diskCount += 1;//Adds 1 to the number of disks in the board.
    }
    
    public function isWin($entity)//Traverses all the elements of the board array and checks if in any direction the given entity won.
    {
        for($x = 0;$x < count($this->entries);$x += 1)
        {
            for($y = 0;$y < count($this->entries[0]);$y += 1)
            {
                if($this->entries[$x][$y] != 'u')//Skips the unused entries.
                {
                    if($this->checkPlaces($x,$y,1,0,$entity))//Checks up direction
                    {
                        return 'true';exit;
                    }
                    else if($this->checkPlaces($x,$y,-1,0,$entity))//Checks down direction
                    {
                        return 'true';exit;
                    }
                    else if($this->checkPlaces($x,$y,0,1,$entity))//Checks to the right direction
                    {
                        return 'true';exit;
                    }
                    else if($this->checkPlaces($x,$y,0,-1,$entity))//Checks to the left direction.
                    {
                        return 'true';exit;
                    }
                    else if($this->checkPlaces($x,$y,1,-1,$entity))//Checks up-left direction.
                    {
                        return 'true';exit;
                    }
                    else if($this->checkPlaces($x,$y,1,1,$entity))//Checks up-right direction.
                    {
                        return 'true';exit;
                    }
                    else if($this->checkPlaces($x,$y,-1,1,$entity))//Checks down-right direction.
                    {
                        return 'true';exit;
                    }
                    else if($this->checkPlaces($x,$y,-1,-1,$entity))//Checks down left direction.
                    {
                        return 'true';exit;
                    }
                }
            }
        }
        return 'false';
    }
    
    public function isDraw()//Check how many disks are placed, if 42 then all entries are used and the game is a draw.
    {
        $numdisks = $this->getDiskNum();
         if($numdisks == 42)
             return 'true';
         return 'false';
    }
    
    public function checkPlaces($x, $y, $dx, $dy, $player) {
        $original_x = $x;
        $original_y = $y;
        $count = 0;
        for($i = 0; $i < 4 && $this->entries[$x][$y] == $player && $x >= 0 && $x < 6 && $y >= 0 && $y < 7; $x += $dx, $y += $dy, $i += 1)//Counts the consecutive 
                                                                                                                                         //entries in the specify direction for a given entity
        {
            if($this->entries[$x][$y] == $player)
                $count += 1;
        }
        if($count == 4)//If 4 then it means an entity has won.
        {
           $coord = array($original_x,$original_y,
                          $original_x+$dx,$original_y+$dy,
                          $original_x+$dx+$dx,$original_y+$dy+$dy,
                          $original_x+$dx+$dx+$dx,$original_y+$dy+$dy+$dy); //The array of entries where a winning combination is found is constructed.
           $this->win_coord = $coord;
           return true;
           exit;
        }
        return false;  
    }
    
    public function setBoard($array,$disks)//This function allows the reconstruction of the state of the board.
    {
        $this -> entries = $array;
        $this -> diskCount = $disks;
    }
    
    public function getBoard()//Provided the array that represents the board to reconstruct it.
    {
        return $this->entries;
    }
    
    public function getCoordinate($x,$y)//Gets the value at the coordinate specificed. 
    {
        return $this->entries[$x][$y];
    }
    
    public function setCoordinate($x,$y,$set)//Sets the coordinate in the board to whatever is indicated.
    {
        $this->entries[$x][$y] = $set;
    }
    
    public function getDiskNum()//Returns the number of disks in the board.
    {
        return $this->diskCount;
    }
}
?>