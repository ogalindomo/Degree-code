<?php 
/**
 * @author oscargalindo
 */
require_once '../play/GameBoard.php';
require_once '../play/RandomStrategy.php';
require_once '../play/SmartStrategy.php';
class Move
{
    public $slot;
    public $isWin;
    public $isDraw;
    public $row;
    function __construct(Board &$reference, $strategy = null, $move_column = null,$entity)
    {
        if ($entity == 'p')//Entity player (p).
        {
            $this->row = array();//The winning row array is initiated as an empty array.
            $this->slot = $move_column;//The slot is assigned to the value provided by the user.
            $reference->placeDisk($move_column,$entity);//A disk is placed in the board.
            $this->isWin = ($reference->isWin($entity));//Checks if the player won.
            $this->isDraw = ($reference->isDraw());//Checks if there is a draw.
            if($this->isWin == 'true')//If the player won then the array of coordinates is assigned to $row
                $this->row = $reference->win_coord;
        }
        else 
        {
            if(strcmp($strategy,"Smart") == 0)
            {
                $this->row = array();//The winning row array is initiated as an empty array.
                $movement = new SmartStrategy($reference);//Strategy is instantiated with a copy of the board.
                $column = $movement->get_new_move();//A new slot is selected by the strategy.
                $this->slot = $column;//The slot played is set to the value retrieved from the strategy.
                $reference->placeDisk($column, $entity);//Makes the movement based on the column chose by the strategy.
                $this->isWin = ($reference->isWin($entity));//Checks if the server won.
                $this->isDraw = ($reference->isDraw());//Checks if there is a draw.
                if ($this->isWin == 'true') //If the player won then the array of coordinates is assigned to $row
                    $this->row = $reference->win_coord;
            }
            else if(strcmp($strategy,"Random") == 0)//Executes if strategy selected is Random.
            {
                $this->row = array();//The winning row array is initiated as an empty array.
                $movement = new RandomStrategy($reference);//Strategy is instantiated with a copy of the board.
                $column = $movement->get_new_move();//A new slot is selected by the strategy.
                $this->slot = $column;//The slot played is set to the value retrieved from the strategy.
                $reference->placeDisk($column, $entity);//Makes the movement based on the column chose by the strategy.
                $this->isWin = ($reference->isWin($entity));//Checks if the server won.
                $this->isDraw = ($reference->isDraw());//Checks if there is a draw.
                if ($this->isWin == 'true') //If the player won then the array of coordinates is assigned to $row
                    $this->row = $reference->win_coord;
            }
        }
    }

}
?>