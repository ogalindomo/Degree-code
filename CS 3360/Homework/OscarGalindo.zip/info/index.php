<?php
define(width, 7);
define(height, 6);

$options = array(//Available difficulty options
    'Smart' => "Smart",
    'Random' => "Random",
);

$info = array(//Constructs the response to the user that connects to the server.
    'width' => width,
    'height' => height,
    'strategies' => array_keys($options)
);
echo json_encode($info);//Echoes the constructed response.
?>

